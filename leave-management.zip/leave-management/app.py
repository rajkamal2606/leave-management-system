"""
Employee Leave Management System
Stack: Flask (Python) + SQLite
Roles: employee (apply / view / cancel) and manager (approve / reject)
"""
import os
import sqlite3
from datetime import date, datetime
from functools import wraps

from flask import (Flask, flash, g, redirect, render_template, request,
                   session, url_for)
from werkzeug.security import check_password_hash, generate_password_hash

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATABASE = os.environ.get("DATABASE_PATH", os.path.join(BASE_DIR, "data", "leave.db"))

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "change-me-in-production")

LEAVE_TYPES = ["Annual Leave", "Sick Leave", "Casual Leave", "Maternity/Paternity", "Unpaid Leave"]


# --------------------------------------------------------------------------
# Database helpers
# --------------------------------------------------------------------------
def get_db():
    """One SQLite connection per request, stored on Flask's `g` object."""
    if "db" not in g:
        os.makedirs(os.path.dirname(DATABASE), exist_ok=True)
        g.db = sqlite3.connect(DATABASE)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db


@app.teardown_appcontext
def close_db(exc):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db():
    """Create tables and seed demo users if the database is empty."""
    db = get_db()
    with open(os.path.join(BASE_DIR, "schema.sql")) as f:
        db.executescript(f.read())
    if db.execute("SELECT COUNT(*) FROM users").fetchone()[0] == 0:
        seed = [
            ("admin", "Alice Manager", "admin123", "manager"),
            ("john", "John Employee", "john123", "employee"),
            ("mary", "Mary Employee", "mary123", "employee"),
        ]
        for username, name, pwd, role in seed:
            db.execute(
                "INSERT INTO users (username, full_name, password_hash, role) VALUES (?,?,?,?)",
                (username, name, generate_password_hash(pwd), role),
            )
        db.commit()


with app.app_context():
    init_db()


# --------------------------------------------------------------------------
# Auth helpers
# --------------------------------------------------------------------------
@app.before_request
def load_user():
    uid = session.get("user_id")
    g.user = None
    if uid is not None:
        g.user = get_db().execute("SELECT * FROM users WHERE id = ?", (uid,)).fetchone()


def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if g.user is None:
            flash("Please log in first.", "warning")
            return redirect(url_for("login"))
        return view(*args, **kwargs)
    return wrapped


def manager_required(view):
    @wraps(view)
    @login_required
    def wrapped(*args, **kwargs):
        if g.user["role"] != "manager":
            flash("Managers only.", "danger")
            return redirect(url_for("dashboard"))
        return view(*args, **kwargs)
    return wrapped


# --------------------------------------------------------------------------
# Routes: authentication
# --------------------------------------------------------------------------
@app.route("/")
def index():
    return redirect(url_for("dashboard" if g.user else "login"))


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form["username"].strip()
        password = request.form["password"]
        user = get_db().execute("SELECT * FROM users WHERE username = ?", (username,)).fetchone()
        if user and check_password_hash(user["password_hash"], password):
            session.clear()
            session["user_id"] = user["id"]
            flash(f"Welcome back, {user['full_name']}!", "success")
            return redirect(url_for("dashboard"))
        flash("Invalid username or password.", "danger")
    return render_template("login.html")


@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        username = request.form["username"].strip()
        full_name = request.form["full_name"].strip()
        password = request.form["password"]
        if not (username and full_name and len(password) >= 6):
            flash("All fields are required and the password needs 6+ characters.", "danger")
            return render_template("register.html")
        db = get_db()
        try:
            db.execute(
                "INSERT INTO users (username, full_name, password_hash, role) VALUES (?,?,?, 'employee')",
                (username, full_name, generate_password_hash(password)),
            )
            db.commit()
        except sqlite3.IntegrityError:
            flash("That username is already taken.", "danger")
            return render_template("register.html")
        flash("Account created. You can log in now.", "success")
        return redirect(url_for("login"))
    return render_template("register.html")


@app.route("/logout")
def logout():
    session.clear()
    flash("You have been logged out.", "info")
    return redirect(url_for("login"))


# --------------------------------------------------------------------------
# Routes: employee features
# --------------------------------------------------------------------------
@app.route("/dashboard")
@login_required
def dashboard():
    db = get_db()
    if g.user["role"] == "manager":
        stats = {
            "pending": db.execute("SELECT COUNT(*) FROM leave_requests WHERE status='Pending'").fetchone()[0],
            "approved": db.execute("SELECT COUNT(*) FROM leave_requests WHERE status='Approved'").fetchone()[0],
            "rejected": db.execute("SELECT COUNT(*) FROM leave_requests WHERE status='Rejected'").fetchone()[0],
            "employees": db.execute("SELECT COUNT(*) FROM users WHERE role='employee'").fetchone()[0],
        }
    else:
        rows = db.execute(
            "SELECT status, COUNT(*) c FROM leave_requests WHERE user_id=? GROUP BY status",
            (g.user["id"],),
        ).fetchall()
        counts = {r["status"]: r["c"] for r in rows}
        stats = {
            "pending": counts.get("Pending", 0),
            "approved": counts.get("Approved", 0),
            "rejected": counts.get("Rejected", 0),
            "balance": g.user["leave_balance"],
        }
    return render_template("dashboard.html", stats=stats)


@app.route("/apply", methods=["GET", "POST"])
@login_required
def apply_leave():
    if g.user["role"] == "manager":
        flash("Managers review requests; log in as an employee to apply.", "info")
        return redirect(url_for("dashboard"))

    if request.method == "POST":
        leave_type = request.form["leave_type"]
        reason = request.form["reason"].strip()
        try:
            start = datetime.strptime(request.form["start_date"], "%Y-%m-%d").date()
            end = datetime.strptime(request.form["end_date"], "%Y-%m-%d").date()
        except ValueError:
            flash("Please enter valid dates.", "danger")
            return render_template("apply.html", leave_types=LEAVE_TYPES, today=date.today())

        error = None
        if leave_type not in LEAVE_TYPES:
            error = "Invalid leave type."
        elif not reason:
            error = "Please give a reason."
        elif end < start:
            error = "End date cannot be before start date."
        elif start < date.today():
            error = "Start date cannot be in the past."

        days = (end - start).days + 1
        db = get_db()

        if not error:
            overlap = db.execute(
                """SELECT 1 FROM leave_requests
                   WHERE user_id=? AND status IN ('Pending','Approved')
                     AND start_date <= ? AND end_date >= ?""",
                (g.user["id"], end.isoformat(), start.isoformat()),
            ).fetchone()
            if overlap:
                error = "You already have a pending/approved request overlapping these dates."
        if not error and leave_type != "Unpaid Leave" and days > g.user["leave_balance"]:
            error = f"Not enough balance. You have {g.user['leave_balance']} day(s) left."

        if error:
            flash(error, "danger")
            return render_template("apply.html", leave_types=LEAVE_TYPES, today=date.today())

        db.execute(
            """INSERT INTO leave_requests (user_id, leave_type, start_date, end_date, days, reason)
               VALUES (?,?,?,?,?,?)""",
            (g.user["id"], leave_type, start.isoformat(), end.isoformat(), days, reason),
        )
        db.commit()
        flash("Leave request submitted and is awaiting approval.", "success")
        return redirect(url_for("my_leaves"))

    return render_template("apply.html", leave_types=LEAVE_TYPES, today=date.today())


@app.route("/my-leaves")
@login_required
def my_leaves():
    rows = get_db().execute(
        """SELECT lr.*, m.full_name AS reviewer
           FROM leave_requests lr LEFT JOIN users m ON m.id = lr.reviewed_by
           WHERE lr.user_id = ? ORDER BY lr.created_at DESC, lr.id DESC""",
        (g.user["id"],),
    ).fetchall()
    return render_template("my_leaves.html", leaves=rows)


@app.route("/cancel/<int:leave_id>", methods=["POST"])
@login_required
def cancel_leave(leave_id):
    db = get_db()
    row = db.execute(
        "SELECT * FROM leave_requests WHERE id=? AND user_id=?", (leave_id, g.user["id"])
    ).fetchone()
    if not row:
        flash("Request not found.", "danger")
    elif row["status"] != "Pending":
        flash("Only pending requests can be cancelled.", "warning")
    else:
        db.execute("UPDATE leave_requests SET status='Cancelled' WHERE id=?", (leave_id,))
        db.commit()
        flash("Request cancelled.", "info")
    return redirect(url_for("my_leaves"))


# --------------------------------------------------------------------------
# Routes: manager features
# --------------------------------------------------------------------------
@app.route("/manage")
@manager_required
def manage():
    status = request.args.get("status", "Pending")
    query = """SELECT lr.*, u.full_name, u.username, u.leave_balance
               FROM leave_requests lr JOIN users u ON u.id = lr.user_id"""
    params = ()
    if status in ("Pending", "Approved", "Rejected", "Cancelled"):
        query += " WHERE lr.status = ?"
        params = (status,)
    else:
        status = "All"
    query += " ORDER BY lr.created_at DESC, lr.id DESC"
    rows = get_db().execute(query, params).fetchall()
    return render_template("manage.html", leaves=rows, current=status)


@app.route("/review/<int:leave_id>", methods=["POST"])
@manager_required
def review(leave_id):
    action = request.form.get("action")
    note = request.form.get("manager_note", "").strip()
    db = get_db()
    row = db.execute("SELECT * FROM leave_requests WHERE id=?", (leave_id,)).fetchone()

    if not row:
        flash("Request not found.", "danger")
    elif row["status"] != "Pending":
        flash("This request has already been processed.", "warning")
    elif action == "approve":
        emp = db.execute("SELECT * FROM users WHERE id=?", (row["user_id"],)).fetchone()
        deduct = 0 if row["leave_type"] == "Unpaid Leave" else row["days"]
        if deduct > emp["leave_balance"]:
            flash(f"Cannot approve: {emp['full_name']} only has {emp['leave_balance']} day(s) left.", "danger")
        else:
            db.execute(
                "UPDATE users SET leave_balance = leave_balance - ? WHERE id = ?",
                (deduct, emp["id"]),
            )
            db.execute(
                """UPDATE leave_requests SET status='Approved', manager_note=?, reviewed_by=?,
                   reviewed_at=CURRENT_TIMESTAMP WHERE id=?""",
                (note, g.user["id"], leave_id),
            )
            db.commit()
            flash("Leave approved.", "success")
    elif action == "reject":
        db.execute(
            """UPDATE leave_requests SET status='Rejected', manager_note=?, reviewed_by=?,
               reviewed_at=CURRENT_TIMESTAMP WHERE id=?""",
            (note, g.user["id"], leave_id),
        )
        db.commit()
        flash("Leave rejected.", "info")
    else:
        flash("Unknown action.", "danger")
    return redirect(url_for("manage"))


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=os.environ.get("FLASK_DEBUG") == "1")
