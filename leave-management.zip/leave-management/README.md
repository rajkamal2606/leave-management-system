# Employee Leave Management System

A Flask + SQLite web app with role-based access (Employee / Manager) and Docker support.

## Features
| Requirement | Where it is implemented |
|---|---|
| User login | `/login`, `/register`, `/logout` in `app.py` (passwords hashed with Werkzeug, session cookies) |
| Apply for leave | `/apply` – validates dates, overlap, and leave balance |
| View requests / status | `/my-leaves` (employee), `/manage` (manager, filter by status) |
| Approve / reject | `/review/<id>` (manager only, optional note; approval deducts balance) |
| Database integration | SQLite via Python `sqlite3`; tables defined in `schema.sql` |
| Docker | `Dockerfile` + `docker-compose.yml` |

## Demo accounts
| Role | Username | Password |
|---|---|---|
| Manager | `admin` | `admin123` |
| Employee | `john` | `john123` |
| Employee | `mary` | `mary123` |

## Run with Docker (recommended)
```bash
docker compose up --build
```
Open http://localhost:5000  
Stop with `Ctrl+C`, or `docker compose down` (add `-v` to also delete the database volume).

Without compose:
```bash
docker build -t leave-app .
docker run -p 5000:5000 -v leave_data:/app/data leave-app
```

## Run without Docker
```bash
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
python app.py
```
Open http://localhost:5000

## Project structure
```
app.py               Flask routes, DB helpers, business rules
schema.sql           users + leave_requests tables
templates/           Jinja2 HTML pages
static/style.css     Styling
Dockerfile           Container image (gunicorn)
docker-compose.yml   Runs the app with a persistent volume for the DB
```

## Workflow (for your demo)
1. **Employee** logs in -> applies for leave -> request saved as `Pending`.
2. **Manager** logs in -> opens *Review Requests* -> approves or rejects (with a note).
3. On approval, the employee's `leave_balance` is reduced by the number of days (Unpaid Leave is not deducted).
4. **Employee** sees the updated status, note and balance in *My Leaves*; pending requests can be cancelled.

## Database design
- `users(id, username, full_name, password_hash, role, leave_balance)`
- `leave_requests(id, user_id -> users.id, leave_type, start_date, end_date, days, reason, status, manager_note, reviewed_by -> users.id, created_at, reviewed_at)`
- Status values: `Pending`, `Approved`, `Rejected`, `Cancelled`

## Business rules
- Start date cannot be in the past; end date cannot be before start date.
- Days = inclusive difference between the two dates.
- Overlapping Pending/Approved requests for the same employee are blocked.
- Requests larger than the remaining balance are blocked (except Unpaid Leave).
- Only managers can approve/reject; only pending requests can be reviewed or cancelled.

## Possible improvements (good talking points)
CSRF protection (Flask-WTF), excluding weekends/holidays from day count, email notifications,
PostgreSQL in a second container, manager-per-team hierarchy, unit tests.
