-- Database schema (SQLite)
CREATE TABLE IF NOT EXISTS users (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    username      TEXT    NOT NULL UNIQUE,
    full_name     TEXT    NOT NULL,
    password_hash TEXT    NOT NULL,
    role          TEXT    NOT NULL CHECK (role IN ('employee', 'manager')),
    leave_balance INTEGER NOT NULL DEFAULT 20
);

CREATE TABLE IF NOT EXISTS leave_requests (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id      INTEGER NOT NULL REFERENCES users(id),
    leave_type   TEXT    NOT NULL,
    start_date   TEXT    NOT NULL,
    end_date     TEXT    NOT NULL,
    days         INTEGER NOT NULL,
    reason       TEXT    NOT NULL,
    status       TEXT    NOT NULL DEFAULT 'Pending'
                 CHECK (status IN ('Pending', 'Approved', 'Rejected', 'Cancelled')),
    manager_note TEXT,
    reviewed_by  INTEGER REFERENCES users(id),
    created_at   TEXT    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    reviewed_at  TEXT
);
